_____ _____ _____ _____ _____ _____ _____ _____ _____ _____ 
|     |   __|  _  |   __|     | __  |     |  _  |_   _|   __|
| | | |   __|   __|__   |   --|    -|-   -|   __| | | |__   |
|_|_|_|__|  |__|  |_____|_____|__|__|_____|__|    |_| |_____|
                                                              
                                           
## Requirements
- [esx_status] (From [esx_status]/esxstatusold for old esx or [esx_status]/esxstatusnew for new esx)
- [esx_basicneeds](https://github.com/esx-framework/esx_basicneeds)
- (ADDITIONAL FOR FREE) --> https://store.mfpscripts.com/

#### DOCS ####
#### VISIT https://docs.maxifaxipaxi.com/scripts/hud FOR MORE! ####


## Installation
- Add this in your `server.cfg`:

```
start mfp_mileage
start mfp_hud
```

Visit https://mfpscripts.com to see other scripts you'll love!


## ChangeLogs

Version 1.0
- release version

Version 1.1
- minor bug fixes with mileage

Version 1.2
- small scale fixes due to more money changed the hud size. Thanks to SkyTier!

Version 1.3
- added FuelScript additions. Use often used fuel scripts or your own custom one.
- Translations in Turkish, Polish, and Russian have been added. Thanks to the community for the support!
- added alternative style.css for higher resolutions, if the HUD is too small for you. This was provided by @wulfer_gaming_19

Version 1.4
- Bugfixes with not getting mileage right
- changed db.sql of mfp_mileage from FLOAT to DOUBLE








###############################################################################################

                     Credits goes to MFPSCRIPTS.com x LuxCoding.de!

###############################################################################################